package com.ablancomziar.billsmanager;

public enum Payment {
    bankcard,
    bankcheck,
    cash;
}
