package com.ablancomziar.billsmanager;

import android.content.Context;
import android.graphics.drawable.Drawable;

public final class DefaultTag implements ITag {
    private String name;
    private Drawable icon;

    private DefaultTag(String name, Drawable Icon) {
        this.name = name;
        icon = Icon;
    }

    static public DefaultTag[] getAllDefaultTag(Context ctx){
        return new DefaultTag[]{
            new DefaultTag(ctx.getString(R.string.alim),null),
            new DefaultTag(ctx.getString(R.string.home),null),
            new DefaultTag(ctx.getString(R.string.life),null),
            new DefaultTag(ctx.getString(R.string.tran),null),
            new DefaultTag(ctx.getString(R.string.heal),null),
            new DefaultTag(ctx.getString(R.string.digi),null)
        };
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public boolean hasIcon() {
        return icon != null;
    }

    @Override
    public Drawable getIcon() {
        return icon;
    }
}
